# Karnataka Tourism & Community Connect (Phase 2)

## Setup
1. `npm install`
2. Create a Firebase project, add a Web app, and copy its config into `.env` (copy `.env.example`).
3. Firebase console: enable Firestore (start in production mode), then paste `firestore.rules` into Firestore > Rules > Publish.
4. Seed the database: download a service account key (Project settings > Service accounts), save it as `serviceAccountKey.json` in this folder, then run `npm run seed`.
5. `npm run dev` and open the link shown. The page lists how many districts, places and stays were loaded (expected: 31, 18, 15).

## Database (Firestore)
- districts: name, description, bestSeason, headerImage, imageCredit
- places: name, districtId, category, description, history, lat, lng, bestMonths[], bestTime, entryFee, openingHours, images[], imageCredit
- stays: name, districtId, type, priceMin, priceMax, rating, lat, lng, contact
- users/{uid}/savedPlaces, users/{uid}/savedTrips
- reviews: targetId, userId, rating, comment, createdAt

## Common errors
- "Firebase is not connected": `.env` is missing or you did not restart `npm run dev`.
- "Missing or insufficient permissions": the rules are not published yet.
- Seed fails with "Cannot find serviceAccountKey.json": the key file is not in the project root.
- Counts show 0: run `npm run seed` again and check the Firestore console.

## Phases 3 to 6
- Login: Firebase console > Authentication > enable Google and Phone (add a test phone number while developing; `localhost` must be an authorized domain).
- AI planner: `npm i -g firebase-tools`, `firebase login`, `firebase use <project-id>`, `cd functions && npm install && cd ..`,
  `firebase functions:secrets:set LLM_API_KEY`, `firebase deploy --only functions`, then copy the function URL into `.env` as VITE_PLANNER_URL.
  (Cloud Functions needs the Blaze plan. The key is never put in website code.)
- Deploy the site: `npm run build` then `firebase deploy --only hosting,firestore:rules`.
- Test order: map route on a place page, log in, save a place, post a review, run the planner.
- Not included yet: user photo uploads and an admin delete role (users can delete their own reviews).
