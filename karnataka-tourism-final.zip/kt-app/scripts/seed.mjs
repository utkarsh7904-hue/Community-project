// Uploads seedData.js to Firestore. Run once: npm run seed
// Needs serviceAccountKey.json in the project root (Firebase console >
// Project settings > Service accounts > Generate new private key).
// Never upload that file to GitHub (it is already in .gitignore).
import admin from "firebase-admin";
import { readFileSync } from "node:fs";
import { districts, places, stays } from "../src/data/seedData.js";

admin.initializeApp({
  credential: admin.credential.cert(JSON.parse(readFileSync("serviceAccountKey.json", "utf8"))),
});
const db = admin.firestore();

async function upload(collectionName, items) {
  const batch = db.batch();
  items.forEach((item) => batch.set(db.collection(collectionName).doc(item.id), item));
  await batch.commit();
  console.log(`Uploaded ${items.length} documents to ${collectionName}`);
}

await upload("districts", districts);
await upload("places", places);
await upload("stays", stays);
