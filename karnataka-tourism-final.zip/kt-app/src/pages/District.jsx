import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useCollection } from "../hooks/useCollection";
import PlaceImage from "../components/PlaceImage";
import { CardSkeleton, Notice } from "../components/Skeleton";

export default function District() {
  const { id } = useParams();
  const districts = useCollection("districts");
  const places = useCollection("places");
  const [category, setCategory] = useState("All");

  const district = districts.data.find((d) => d.id === id);
  const list = places.data.filter((p) => p.districtId === id);
  const categories = ["All", ...new Set(list.map((p) => p.category))];
  const shown = category === "All" ? list : list.filter((p) => p.category === category);
  const loading = districts.loading || places.loading;
  const error = districts.error || places.error;

  return (
    <main className="mx-auto max-w-5xl px-4 py-8">
      <Link to="/" className="text-forest underline">All districts</Link>
      {error && <div className="mt-4"><Notice tone="error">{error}</Notice></div>}
      {!loading && !error && !district && <p className="mt-4">District not found. Go back and pick one from the list.</p>}

      {district && (
        <>
          <h1 className="mt-2 text-3xl font-bold text-forest">{district.name}</h1>
          <p className="mt-2 max-w-2xl">{district.description}</p>
          <p className="mt-1 text-sm">Best season: <strong>{district.bestSeason}</strong></p>

          <div className="my-5 flex flex-wrap gap-2" role="group" aria-label="Filter by category">
            {categories.map((c) => (
              <button key={c} onClick={() => setCategory(c)} aria-pressed={c === category}
                className={`rounded-full border px-4 py-1 text-sm ${c === category ? "border-forest bg-forest text-white" : "border-forest/30 bg-white"}`}>
                {c}
              </button>
            ))}
          </div>
        </>
      )}

      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3" aria-label="Tourist places">
        {loading && <CardSkeleton count={3} />}
        {shown.map((p) => (
          <Link key={p.id} to={`/place/${p.id}`} className="rounded-lg border border-forest/15 bg-white hover:border-saffron">
            <PlaceImage src={p.images?.[0]} alt={p.name} credit={p.imageCredit} />
            <div className="p-4">
              <h2 className="text-lg font-semibold text-forest">{p.name}</h2>
              <p className="text-sm text-ink/70">{p.category}</p>
              <p className="mt-1 text-sm">{p.description}</p>
            </div>
          </Link>
        ))}
      </section>
      {!loading && district && shown.length === 0 && <p>No places in this category yet.</p>}
    </main>
  );
}
