import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../services/firebase";
import { useAuth } from "../services/AuthContext";
import { useCollection } from "../hooks/useCollection";

export default function Saved() {
  const { user } = useAuth();
  const places = useCollection("places");
  const [ids, setIds] = useState([]);
  const [trips, setTrips] = useState([]);

  useEffect(() => {
    getDocs(collection(db, "users", user.uid, "savedPlaces")).then((s) => setIds(s.docs.map((d) => d.id)));
    getDocs(collection(db, "users", user.uid, "savedTrips")).then((s) => setTrips(s.docs.map((d) => ({ id: d.id, ...d.data() }))));
  }, [user]);

  const saved = places.data.filter((p) => ids.includes(p.id));
  return (
    <main className="mx-auto max-w-3xl px-4 py-8">
      <h1 className="text-3xl font-bold text-forest">Saved</h1>
      <h2 className="mt-5 text-xl font-semibold">Places</h2>
      <ul className="list-disc pl-5">
        {saved.map((p) => <li key={p.id}><Link to={`/place/${p.id}`} className="text-forest underline">{p.name}</Link></li>)}
      </ul>
      {saved.length === 0 && <p>Nothing saved yet. Open a place and choose Save place.</p>}
      <h2 className="mt-5 text-xl font-semibold">Trips</h2>
      {trips.map((t) => (
        <p key={t.id} className="mt-2 rounded border border-forest/15 bg-white p-3">
          <strong>{t.districtName}, {t.days.length} days</strong>. {t.summary}
        </p>
      ))}
      {trips.length === 0 && <p>No saved trips. Make one in the Trip planner.</p>}
    </main>
  );
}
