import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { GoogleAuthProvider, signInWithPopup, RecaptchaVerifier, signInWithPhoneNumber } from "firebase/auth";
import { auth } from "../services/firebase";
import { Notice } from "../components/Skeleton";

export default function Login() {
  const navigate = useNavigate();
  const [phone, setPhone] = useState("+91");
  const [otp, setOtp] = useState("");
  const [confirmation, setConfirmation] = useState(null);
  const [error, setError] = useState("");

  if (!auth) return <main className="p-8"><Notice tone="error">Login needs Firebase keys in your .env file.</Notice></main>;

  const run = (fn, msg) => async () => {
    try { await fn(); setError(""); } catch (e) { setError(`${msg}: ${e.code || e.message}`); }
  };
  const google = run(async () => { await signInWithPopup(auth, new GoogleAuthProvider()); navigate("/"); }, "Google sign-in failed");
  const sendOtp = run(async () => {
    window.verifier ||= new RecaptchaVerifier(auth, "recaptcha", { size: "invisible" });
    setConfirmation(await signInWithPhoneNumber(auth, phone, window.verifier));
  }, "Could not send OTP");
  const verify = run(async () => { await confirmation.confirm(otp); navigate("/"); }, "Wrong OTP");

  const input = "w-full rounded border border-forest/30 bg-white p-2";
  return (
    <main className="mx-auto max-w-sm px-4 py-8">
      <h1 className="mb-4 text-3xl font-bold text-forest">Log in</h1>
      <button onClick={google} className="w-full rounded bg-forest px-4 py-2 text-white">Continue with Google</button>
      <h2 className="mb-2 mt-6 font-semibold">Or use your mobile number</h2>
      <label className="block text-sm">Phone number with country code
        <input value={phone} onChange={(e) => setPhone(e.target.value)} className={input} />
      </label>
      <button onClick={sendOtp} className="my-2 rounded bg-saffron px-4 py-2">Send OTP</button>
      {confirmation && (
        <>
          <label className="block text-sm">Enter OTP
            <input value={otp} onChange={(e) => setOtp(e.target.value)} inputMode="numeric" className={input} />
          </label>
          <button onClick={verify} className="mt-2 rounded bg-forest px-4 py-2 text-white">Verify and log in</button>
        </>
      )}
      <div id="recaptcha" />
      {error && <div className="mt-4"><Notice tone="error">{error}</Notice></div>}
    </main>
  );
}
