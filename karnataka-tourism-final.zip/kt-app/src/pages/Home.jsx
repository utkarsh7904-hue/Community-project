import { Link } from "react-router-dom";
import { useCollection } from "../hooks/useCollection";
import DistrictSearch from "../components/DistrictSearch";
import PlaceImage from "../components/PlaceImage";
import { CardSkeleton, Notice } from "../components/Skeleton";

export default function Home() {
  const { data, loading, error } = useCollection("districts");
  const districts = [...data].sort((a, b) => a.name.localeCompare(b.name));

  return (
    <main className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="text-3xl font-bold text-forest sm:text-4xl">Find where to go in Karnataka</h1>
      <p className="mb-5 mt-2 max-w-xl">Pick a district to see its places, where to stay and the best time to visit.</p>
      <DistrictSearch districts={districts} />

      {error && <div className="mt-6"><Notice tone="error">{error}</Notice></div>}
      <section className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3" aria-label="Districts">
        {loading && <CardSkeleton />}
        {districts.map((d) => (
          <Link key={d.id} to={`/district/${d.id}`} className="rounded-lg border border-forest/15 bg-white hover:border-saffron">
            <PlaceImage src={d.headerImage} alt={d.name} credit={d.imageCredit} />
            <div className="p-4">
              <h2 className="text-lg font-semibold text-forest">{d.name}</h2>
              <p className="text-sm">{d.description}</p>
            </div>
          </Link>
        ))}
      </section>
    </main>
  );
}
