import { useState } from "react";
import { addDoc, collection } from "firebase/firestore";
import { db } from "../services/firebase";
import { useAuth } from "../services/AuthContext";
import { useCollection } from "../hooks/useCollection";
import { Notice } from "../components/Skeleton";

const PLANNER_URL = import.meta.env.VITE_PLANNER_URL;

export default function Planner() {
  const { user } = useAuth();
  const districts = useCollection("districts");
  const [form, setForm] = useState({ startCity: "Bengaluru", districtId: "kodagu", days: 2, budget: 8000, travellers: 2, month: "December", preference: "nature" });
  const [plan, setPlan] = useState(null);
  const [state, setState] = useState({ loading: false, error: "", saved: false });

  const set = (k, num) => (e) => setForm({ ...form, [k]: num ? Number(e.target.value) : e.target.value });

  async function submit(e) {
    e.preventDefault();
    if (!PLANNER_URL) return setState({ ...state, error: "Planner is not connected. Deploy the Cloud Function and set VITE_PLANNER_URL in .env." });
    setState({ loading: true, error: "", saved: false });
    setPlan(null);
    try {
      const res = await fetch(PLANNER_URL, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Planner failed");
      setPlan(data);
      setState({ loading: false, error: "", saved: false });
    } catch (err) {
      setState({ loading: false, error: err.message, saved: false });
    }
  }

  async function save() {
    const districtName = districts.data.find((d) => d.id === form.districtId)?.name || form.districtId;
    await addDoc(collection(db, "users", user.uid, "savedTrips"), { ...plan, districtName, createdAt: Date.now() });
    setState({ ...state, saved: true });
  }

  const f = "block w-full rounded border border-forest/30 bg-white p-2";
  return (
    <main className="mx-auto max-w-3xl px-4 py-8">
      <h1 className="text-3xl font-bold text-forest">Trip planner</h1>
      <form onSubmit={submit} className="my-5 grid gap-3 sm:grid-cols-2">
        <label>Starting city<input className={f} value={form.startCity} onChange={set("startCity")} /></label>
        <label>District
          <select className={f} value={form.districtId} onChange={set("districtId")}>
            {[...districts.data].sort((a, b) => a.name.localeCompare(b.name)).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
        </label>
        <label>Days<input className={f} type="number" min="1" max="7" value={form.days} onChange={set("days", true)} /></label>
        <label>Total budget (Rs)<input className={f} type="number" min="1000" step="500" value={form.budget} onChange={set("budget", true)} /></label>
        <label>Travellers<input className={f} type="number" min="1" max="10" value={form.travellers} onChange={set("travellers", true)} /></label>
        <label>Month of travel<input className={f} value={form.month} onChange={set("month")} /></label>
        <label>Preference
          <select className={f} value={form.preference} onChange={set("preference")}>
            {["nature", "heritage", "adventure", "relaxed"].map((p) => <option key={p}>{p}</option>)}
          </select>
        </label>
        <button disabled={state.loading} className="self-end rounded bg-forest px-4 py-2 text-white disabled:opacity-50">
          {state.loading ? "Planning..." : "Plan my trip"}
        </button>
      </form>

      {state.error && <Notice tone="error">{state.error}</Notice>}
      {plan && (
        <section aria-label="Your plan">
          <p className="mb-2">{plan.summary}</p>
          {plan.budgetNote && <Notice>{plan.budgetNote}</Notice>}
          <ol className="mt-3 space-y-3 border-l-4 border-saffron pl-4">
            {plan.days.map((d) => (
              <li key={d.day} className="rounded bg-white p-3">
                <h2 className="font-semibold text-forest">Day {d.day}</h2>
                <ul className="list-disc pl-5">{d.places.map((p) => <li key={p.name}>{p.name}: best at {p.bestTime}</li>)}</ul>
                {d.stopsOnTheWay?.length > 0 && <p className="text-sm">On the way: {d.stopsOnTheWay.join(", ")}</p>}
                {d.stay && <p className="text-sm">Stay: {d.stay.name}, about Rs {d.stay.pricePerNight} per night</p>}
              </li>
            ))}
          </ol>
          <p className="mt-3">Best time to visit: {plan.bestMonthNote}</p>
          <p>Estimated cost: stay Rs {plan.costBreakdown.stay}, food Rs {plan.costBreakdown.food}, transport Rs {plan.costBreakdown.transport}, entry Rs {plan.costBreakdown.entryFees}</p>
          {user
            ? <button onClick={save} disabled={state.saved} className="mt-3 rounded bg-saffron px-4 py-2">{state.saved ? "Trip saved" : "Save this trip"}</button>
            : <p className="mt-3 text-sm">Log in to save this trip.</p>}
        </section>
      )}
    </main>
  );
}
