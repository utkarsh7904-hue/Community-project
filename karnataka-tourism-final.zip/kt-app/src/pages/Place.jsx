import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useCollection } from "../hooks/useCollection";
import { distanceKm } from "../utils/geo";
import PlaceImage from "../components/PlaceImage";
import { Notice } from "../components/Skeleton";
import PlaceMap from "../components/PlaceMap";
import SaveButton from "../components/SaveButton";
import Reviews from "../components/Reviews";

export default function Place() {
  const { id } = useParams();
  const places = useCollection("places");
  const stays = useCollection("stays");
  const [type, setType] = useState("All");
  const [maxPrice, setMaxPrice] = useState(0); // 0 = any

  const place = places.data.find((p) => p.id === id);
  const error = places.error || stays.error;

  // Stays in the same district, nearest first
  const nearby = place
    ? stays.data
        .filter((s) => s.districtId === place.districtId)
        .map((s) => ({ ...s, km: distanceKm(place.lat, place.lng, s.lat, s.lng) }))
        .sort((a, b) => a.km - b.km)
    : [];
  const types = ["All", ...new Set(nearby.map((s) => s.type))];
  const shownStays = nearby.filter((s) => (type === "All" || s.type === type) && (!maxPrice || s.priceMin <= maxPrice));

  if (places.loading) return <main className="mx-auto max-w-5xl p-8"><div className="h-64 animate-pulse rounded-lg bg-forest/10" /></main>;

  return (
    <main className="mx-auto max-w-5xl px-4 py-8">
      {error && <Notice tone="error">{error}</Notice>}
      {!place && !error && <p>Place not found. <Link to="/" className="text-forest underline">Back to districts</Link></p>}

      {place && (
        <>
          <Link to={`/district/${place.districtId}`} className="text-forest underline">Back to district</Link>
          <h1 className="mt-2 text-3xl font-bold text-forest">{place.name}</h1>
          <SaveButton placeId={place.id} />
          <p className="mt-1">{place.description}</p>

          <section className="my-5 grid gap-3 sm:grid-cols-2" aria-label="Photos">
            {place.images?.length ? place.images.map((src, i) => (
              <PlaceImage key={i} src={src} alt={`${place.name} photo ${i + 1}`} credit={place.imageCredit} className="h-56" />
            )) : <PlaceImage alt="" className="h-56" />}
          </section>

          <dl className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[
              ["Best months", place.bestMonths?.join(", ")],
              ["Best time of day", place.bestTime],
              ["Entry fee", place.entryFee],
              ["Opening hours", place.openingHours],
            ].map(([label, value]) => (
              <div key={label} className="rounded-lg border border-forest/15 bg-white p-3">
                <dt className="text-xs text-ink/60">{label}</dt>
                <dd className="font-semibold">{value || "Not added yet"}</dd>
              </div>
            ))}
          </dl>

          <h2 className="mb-1 mt-6 text-xl font-semibold text-forest">History</h2>
          <p className="max-w-2xl">{place.history}</p>

          <PlaceMap place={place} stays={shownStays} />

          <h2 className="mb-2 mt-6 text-xl font-semibold text-forest">Stays nearby</h2>
          <div className="mb-3 flex flex-wrap items-center gap-2">
            {types.map((t) => (
              <button key={t} onClick={() => setType(t)} aria-pressed={t === type}
                className={`rounded-full border px-4 py-1 text-sm ${t === type ? "border-forest bg-forest text-white" : "border-forest/30 bg-white"}`}>
                {t}
              </button>
            ))}
            <label className="ml-auto text-sm">Price per night{" "}
              <select value={maxPrice} onChange={(e) => setMaxPrice(Number(e.target.value))} className="rounded border border-forest/30 bg-white p-1">
                <option value={0}>Any</option>
                <option value={1500}>Up to Rs 1,500</option>
                <option value={3000}>Up to Rs 3,000</option>
                <option value={6000}>Up to Rs 6,000</option>
              </select>
            </label>
          </div>
          <ul className="space-y-2">
            {shownStays.map((s) => (
              <li key={s.id} className="rounded-lg border border-forest/15 bg-white p-3">
                <strong>{s.name}</strong> ({s.type}), Rs {s.priceMin} to {s.priceMax} per night, {s.km.toFixed(1)} km away
              </li>
            ))}
          </ul>
          {!stays.loading && shownStays.length === 0 && <p>No stays match these filters. Try a different type or price.</p>}
          <Reviews targetId={place.id} />
        </>
      )}
    </main>
  );
}
