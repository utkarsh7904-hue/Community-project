// SEED DATA. Everything marked TODO must be verified by you before submission
// (coordinates are approximate; copy exact ones from Google Maps).
// Add images later with: Wikimedia Commons URL + credit in imageCredit.

const slug = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

// All 31 districts. Only 3 have descriptions for now.
// TODO: confirm the current list (Ramanagara was renamed Bengaluru South).
const names = [
  "Bagalkot", "Ballari", "Belagavi", "Bengaluru Rural", "Bengaluru Urban", "Bidar",
  "Chamarajanagar", "Chikkaballapur", "Chikkamagaluru", "Chitradurga", "Dakshina Kannada",
  "Davanagere", "Dharwad", "Gadag", "Hassan", "Haveri", "Kalaburagi", "Kodagu", "Kolar",
  "Koppal", "Mandya", "Mysuru", "Raichur", "Ramanagara", "Shivamogga", "Tumakuru", "Udupi",
  "Uttara Kannada", "Vijayanagara", "Vijayapura", "Yadgir",
];
const info = {
  mysuru: ["Palaces, silk and the Dasara festival", "October to February"],
  kodagu: ["Coffee estates and misty hills", "October to March"],
  udupi: ["Temple town on the coast", "October to March"],
};
export const districts = names.map((name) => {
  const id = slug(name);
  return {
    id, name,
    description: info[id]?.[0] ?? "TODO: add description",
    bestSeason: info[id]?.[1] ?? "TODO",
    headerImage: "", imageCredit: "",
  };
});

// [district, name, category, lat, lng, bestMonths, bestTime]
const placeRows = [
  ["mysuru", "Mysore Palace", "Heritage", 12.3052, 76.6552, ["Oct", "Nov", "Dec", "Jan", "Feb"], "Morning"],
  ["mysuru", "Chamundi Hills", "Temple", 12.2724, 76.67, ["Oct", "Nov", "Dec", "Jan", "Feb"], "Early morning"],
  ["mysuru", "Brindavan Gardens", "Nature", 12.4244, 76.5726, ["Sep", "Oct", "Nov", "Dec", "Jan", "Feb"], "Evening"],
  ["mysuru", "Mysore Zoo", "Nature", 12.3015, 76.662, ["Oct", "Nov", "Dec", "Jan", "Feb"], "Morning"],
  ["mysuru", "Jaganmohan Palace", "Heritage", 12.3086, 76.6487, ["Oct", "Nov", "Dec", "Jan", "Feb"], "Morning"],
  ["mysuru", "St. Philomena's Church", "Heritage", 12.3142, 76.6577, ["Oct", "Nov", "Dec", "Jan", "Feb"], "Morning"],
  ["kodagu", "Abbey Falls", "Nature", 12.4553, 75.7185, ["Aug", "Sep", "Oct", "Nov", "Dec"], "Morning"],
  ["kodagu", "Raja's Seat", "Nature", 12.4195, 75.738, ["Oct", "Nov", "Dec", "Jan", "Feb", "Mar"], "Evening"],
  ["kodagu", "Dubare Elephant Camp", "Adventure", 12.387, 75.923, ["Oct", "Nov", "Dec", "Jan", "Feb", "Mar"], "Morning"],
  ["kodagu", "Talakaveri", "Temple", 12.3834, 75.4964, ["Oct", "Nov", "Dec", "Jan", "Feb"], "Morning"],
  ["kodagu", "Namdroling Monastery", "Temple", 12.4858, 75.9655, ["Oct", "Nov", "Dec", "Jan", "Feb", "Mar"], "Morning"],
  ["kodagu", "Madikeri Fort", "Heritage", 12.4244, 75.7382, ["Oct", "Nov", "Dec", "Jan", "Feb", "Mar"], "Morning"],
  ["udupi", "Sri Krishna Temple", "Temple", 13.3409, 74.7421, ["Oct", "Nov", "Dec", "Jan", "Feb", "Mar"], "Morning"],
  ["udupi", "Malpe Beach", "Beach", 13.379, 74.704, ["Nov", "Dec", "Jan", "Feb"], "Evening"],
  ["udupi", "St Mary's Island", "Beach", 13.3797, 74.6747, ["Nov", "Dec", "Jan", "Feb", "Mar"], "Morning"],
  ["udupi", "Kaup Beach", "Beach", 13.2155, 74.7456, ["Nov", "Dec", "Jan", "Feb"], "Evening"],
  ["udupi", "Kodi Bengre", "Beach", 13.4283, 74.7003, ["Nov", "Dec", "Jan", "Feb"], "Evening"],
  ["udupi", "Anantheshwara Temple", "Temple", 13.3411, 74.7418, ["Oct", "Nov", "Dec", "Jan", "Feb", "Mar"], "Morning"],
];
export const places = placeRows.map(([districtId, name, category, lat, lng, bestMonths, bestTime]) => ({
  id: slug(name), districtId, name, category, lat, lng, bestMonths, bestTime,
  description: "TODO: write a short description",
  history: "TODO: add history from Wikipedia and rewrite in your own words",
  entryFee: "TODO", openingHours: "TODO", images: [], imageCredit: "",
}));

// SAMPLE STAYS. Replace the names with real, verified hotels, resorts and dorms.
// [district, type, priceMin, priceMax, lat, lng]
const stayRows = [
  ["mysuru", "Hotel", 3000, 6000, 12.31, 76.65], ["mysuru", "Dorm", 500, 900, 12.3, 76.64],
  ["mysuru", "Resort", 6000, 12000, 12.35, 76.6], ["mysuru", "Homestay", 1500, 2500, 12.29, 76.66],
  ["mysuru", "Hotel", 1200, 2200, 12.305, 76.655],
  ["kodagu", "Resort", 5000, 9000, 12.43, 75.74], ["kodagu", "Homestay", 1500, 2500, 12.42, 75.73],
  ["kodagu", "Dorm", 600, 1000, 12.425, 75.735], ["kodagu", "Hotel", 2500, 4500, 12.415, 75.745],
  ["kodagu", "Resort", 7000, 14000, 12.46, 75.72],
  ["udupi", "Resort", 4000, 8000, 13.37, 74.7], ["udupi", "Hotel", 1000, 2000, 13.34, 74.75],
  ["udupi", "Dorm", 400, 800, 13.345, 74.745], ["udupi", "Homestay", 1200, 2200, 13.36, 74.72],
  ["udupi", "Hotel", 2500, 4000, 13.338, 74.74],
];
export const stays = stayRows.map(([districtId, type, priceMin, priceMax, lat, lng], i) => ({
  id: `${districtId}-stay-${i + 1}`, districtId, type, priceMin, priceMax, lat, lng,
  name: `Sample ${type} ${i + 1} (replace)`, rating: null, contact: "TODO",
}));
