// Shows a photo with its credit, or a plain block when no photo has been added yet
export default function PlaceImage({ src, alt, credit, className = "h-36" }) {
  if (!src) {
    return (
      <div className={`flex items-center justify-center rounded-t-lg bg-forest/15 text-sm text-forest ${className}`}>
        No photo yet
      </div>
    );
  }
  return (
    <figure>
      <img src={src} alt={alt} loading="lazy" className={`w-full rounded-t-lg object-cover ${className}`} />
      {credit && <figcaption className="px-1 text-xs text-ink/60">{credit}</figcaption>}
    </figure>
  );
}
