// Grey placeholder shown while data loads
export function CardSkeleton({ count = 6 }) {
  return Array.from({ length: count }, (_, i) => (
    <div key={i} className="h-44 animate-pulse rounded-lg bg-forest/10" aria-hidden="true" />
  ));
}
export const Notice = ({ children, tone = "info" }) => (
  <p className={`rounded p-3 ${tone === "error" ? "bg-red-100 text-red-800" : "bg-saffron/20"}`} role="status">{children}</p>
);
