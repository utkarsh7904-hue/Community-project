import { useState } from "react";
import { useNavigate } from "react-router-dom";

// Search box with suggestions. Enter opens the first match; arrow keys are not needed
// because every suggestion is also a normal link-style button reachable with Tab.
export default function DistrictSearch({ districts }) {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();
  const q = query.trim().toLowerCase();
  const matches = q ? districts.filter((d) => d.name.toLowerCase().includes(q)).slice(0, 6) : [];

  return (
    <div className="relative max-w-md">
      <input
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && matches[0] && navigate(`/district/${matches[0].id}`)}
        placeholder="Search a district, e.g. Kodagu"
        aria-label="Search districts"
        className="w-full rounded-lg border border-forest/30 bg-white px-4 py-3"
      />
      {q && (
        <ul className="absolute z-10 mt-1 w-full rounded-lg border border-forest/20 bg-white shadow">
          {matches.map((d) => (
            <li key={d.id}>
              <button onClick={() => navigate(`/district/${d.id}`)} className="w-full px-4 py-2 text-left hover:bg-saffron/20">
                {d.name}
              </button>
            </li>
          ))}
          {matches.length === 0 && <li className="px-4 py-2 text-ink/70">No district matches "{query}"</li>}
        </ul>
      )}
    </div>
  );
}
