import { Link } from "react-router-dom";
import { useAuth } from "../services/AuthContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  return (
    <header className="bg-forest text-white">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
        <Link to="/" className="border-b-4 border-saffron text-lg font-bold">Karnataka Tourism</Link>
        <nav className="flex gap-4 text-sm">
          <Link to="/" className="hover:underline">Districts</Link>
          <Link to="/planner" className="hover:underline">Trip planner</Link>
          {user && <Link to="/saved" className="hover:underline">Saved</Link>}
          {user ? <button onClick={logout} className="hover:underline">Log out</button> : <Link to="/login" className="hover:underline">Log in</Link>}
        </nav>
      </div>
    </header>
  );
}
