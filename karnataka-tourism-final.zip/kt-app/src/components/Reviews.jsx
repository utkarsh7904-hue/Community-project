import { useEffect, useState } from "react";
import { addDoc, collection, deleteDoc, doc, getDocs, query, serverTimestamp, where } from "firebase/firestore";
import { db } from "../services/firebase";
import { useAuth } from "../services/AuthContext";

export default function Reviews({ targetId }) {
  const { user } = useAuth();
  const [items, setItems] = useState([]);
  const [rating, setRating] = useState(5);
  const [text, setText] = useState("");
  const [error, setError] = useState("");

  const load = () =>
    getDocs(query(collection(db, "reviews"), where("targetId", "==", targetId)))
      .then((s) => setItems(s.docs.map((d) => ({ id: d.id, ...d.data() }))))
      .catch((e) => setError(e.message));
  useEffect(() => { db && load(); }, [targetId]);

  async function submit(e) {
    e.preventDefault();
    if (!text.trim()) return setError("Write a short comment before posting.");
    try {
      await addDoc(collection(db, "reviews"), { targetId, userId: user.uid, userName: user.displayName || "Traveller", rating, comment: text.trim(), createdAt: serverTimestamp() });
      setText(""); setError(""); load();
    } catch (err) { setError(err.message); }
  }
  const remove = async (id) => { await deleteDoc(doc(db, "reviews", id)); load(); };
  const avg = items.length ? (items.reduce((s, r) => s + r.rating, 0) / items.length).toFixed(1) : null;

  return (
    <section aria-label="Reviews">
      <h2 className="mb-2 mt-6 text-xl font-semibold text-forest">Reviews {avg && `(${avg} out of 5, ${items.length})`}</h2>
      {user ? (
        <form onSubmit={submit} className="mb-3 space-y-2">
          <label className="text-sm">Rating{" "}
            <select value={rating} onChange={(e) => setRating(Number(e.target.value))} className="rounded border border-forest/30 bg-white p-1">
              {[5, 4, 3, 2, 1].map((n) => <option key={n}>{n}</option>)}
            </select>
          </label>
          <textarea value={text} onChange={(e) => setText(e.target.value)} aria-label="Your review" rows={3} className="w-full rounded border border-forest/30 bg-white p-2" />
          <button className="rounded bg-forest px-4 py-2 text-white">Post review</button>
        </form>
      ) : <p className="mb-3 text-sm">Log in to write a review.</p>}
      {error && <p role="alert" className="text-red-800">{error}</p>}
      {items.map((r) => (
        <p key={r.id} className="mb-2 rounded border border-forest/15 bg-white p-3">
          <strong>{r.userName}</strong>: {r.rating} out of 5. {r.comment}{" "}
          {user?.uid === r.userId && <button onClick={() => remove(r.id)} className="text-sm text-red-800 underline">Delete</button>}
        </p>
      ))}
      {items.length === 0 && <p>No reviews yet. Be the first to write one.</p>}
    </section>
  );
}
