import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { deleteDoc, doc, getDoc, setDoc } from "firebase/firestore";
import { db } from "../services/firebase";
import { useAuth } from "../services/AuthContext";

// Saves a place under users/{uid}/savedPlaces (the rules only let you touch your own)
export default function SaveButton({ placeId }) {
  const { user } = useAuth();
  const [saved, setSaved] = useState(false);
  const ref = user && db ? doc(db, "users", user.uid, "savedPlaces", placeId) : null;

  useEffect(() => { ref && getDoc(ref).then((s) => setSaved(s.exists())).catch(() => {}); }, [user, placeId]);

  if (!user) return <Link to="/login" className="text-forest underline">Log in to save this place</Link>;
  const toggle = async () => {
    if (saved) await deleteDoc(ref); else await setDoc(ref, { placeId, savedAt: Date.now() });
    setSaved(!saved);
  };
  return (
    <button onClick={toggle} aria-pressed={saved} className="rounded border border-forest px-3 py-1 text-sm">
      {saved ? "Saved (click to remove)" : "Save place"}
    </button>
  );
}
