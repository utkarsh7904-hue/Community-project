import { useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, Polyline } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import icon from "leaflet/dist/images/marker-icon.png";
import shadow from "leaflet/dist/images/marker-shadow.png";
import { getRoute } from "../utils/geo";

L.Marker.prototype.options.icon = L.icon({ iconUrl: icon, shadowUrl: shadow, iconSize: [25, 41], iconAnchor: [12, 41] });
const BENGALURU = { lat: 12.9716, lng: 77.5946 };

// Map with the place, nearby stays, and a driving route from Bengaluru or the visitor's location
export default function PlaceMap({ place, stays }) {
  const [route, setRoute] = useState(null);
  const [msg, setMsg] = useState("");

  async function show(from) {
    setMsg("Loading route...");
    try { setRoute(await getRoute(from, place)); setMsg(""); }
    catch (e) { setMsg(e.message + ". Check your internet connection and try again."); }
  }
  const myLocation = () =>
    navigator.geolocation.getCurrentPosition(
      (p) => show({ lat: p.coords.latitude, lng: p.coords.longitude }),
      () => setMsg("Location permission was denied. Use the Bengaluru button instead.")
    );

  return (
    <section aria-label="Map and directions">
      <h2 className="mb-2 mt-6 text-xl font-semibold text-forest">Map and directions</h2>
      <div className="mb-2 flex flex-wrap items-center gap-2">
        <button onClick={() => show(BENGALURU)} className="rounded bg-forest px-4 py-2 text-white">Route from Bengaluru</button>
        <button onClick={myLocation} className="rounded bg-forest px-4 py-2 text-white">Route from my location</button>
        {route && <span>By road: <strong>{route.km.toFixed(0)} km</strong>, about <strong>{route.hours.toFixed(1)} hours</strong></span>}
      </div>
      {msg && <p role="status" className="mb-2 text-sm">{msg}</p>}
      <MapContainer key={place.id} center={[place.lat, place.lng]} zoom={11} style={{ height: 380 }} className="rounded-lg">
        <TileLayer attribution="&copy; OpenStreetMap contributors" url="https://tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <Marker position={[place.lat, place.lng]}><Popup>{place.name}</Popup></Marker>
        {stays.map((s) => (
          <Marker key={s.id} position={[s.lat, s.lng]}><Popup>{s.name} ({s.type})</Popup></Marker>
        ))}
        {route && <Polyline positions={route.path} color="#0f4d3a" weight={5} />}
      </MapContainer>
    </section>
  );
}
