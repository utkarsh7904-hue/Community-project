// Straight-line distance in km between two lat/lng points (haversine formula)
export function distanceKm(lat1, lng1, lat2, lng2) {
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// Road route from the free public OSRM server (fine for a college demo)
export async function getRoute(from, to) {
  const url = `https://router.project-osrm.org/route/v1/driving/${from.lng},${from.lat};${to.lng},${to.lat}?overview=full&geometries=geojson`;
  const res = await fetch(url);
  if (!res.ok) throw new Error("Route service is not responding");
  const route = (await res.json()).routes?.[0];
  if (!route) throw new Error("No road route found");
  return {
    km: route.distance / 1000,
    hours: route.duration / 3600,
    path: route.geometry.coordinates.map(([lng, lat]) => [lat, lng]), // OSRM gives lng,lat; Leaflet wants lat,lng
  };
}
