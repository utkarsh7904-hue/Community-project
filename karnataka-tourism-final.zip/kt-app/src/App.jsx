import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import District from "./pages/District";
import Place from "./pages/Place";
import Login from "./pages/Login";
import Planner from "./pages/Planner";
import Saved from "./pages/Saved";
import ProtectedRoute from "./components/ProtectedRoute";
import { AuthProvider } from "./services/AuthContext";

export default function App() {
  return (
    <AuthProvider>
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/district/:id" element={<District />} />
        <Route path="/place/:id" element={<Place />} />
        <Route path="/login" element={<Login />} />
        <Route path="/planner" element={<Planner />} />
        <Route path="/saved" element={<ProtectedRoute><Saved /></ProtectedRoute>} />
        <Route path="*" element={<main className="p-8">Page not found.</main>} />
      </Routes>
    </BrowserRouter>
    </AuthProvider>
  );
}
