// Loads a whole Firestore collection once and remembers it, so moving between pages is instant.
import { useEffect, useState } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db, firebaseReady } from "../services/firebase";

const cache = {};

export function useCollection(name) {
  const [state, setState] = useState({ data: cache[name] || [], loading: !cache[name], error: "" });

  useEffect(() => {
    if (cache[name]) return;
    if (!firebaseReady) {
      setState({ data: [], loading: false, error: "Firebase is not connected. Fill in your .env file and restart npm run dev." });
      return;
    }
    getDocs(collection(db, name))
      .then((snap) => {
        cache[name] = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
        setState({ data: cache[name], loading: false, error: "" });
      })
      .catch((e) => setState({ data: [], loading: false, error: e.message }));
  }, [name]);

  return state;
}
