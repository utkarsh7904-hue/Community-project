// AI trip planner. The API key exists only here (secret LLM_API_KEY), never in the website code.
const { onRequest } = require("firebase-functions/v2/https");
const admin = require("firebase-admin");
admin.initializeApp();

const km = (a, b) => {
  const r = (d) => (d * Math.PI) / 180;
  const x = Math.sin(r(b.lat - a.lat) / 2) ** 2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(r(b.lng - a.lng) / 2) ** 2;
  return Math.round(12742 * Math.asin(Math.sqrt(x)));
};

exports.planTrip = onRequest({ secrets: ["LLM_API_KEY"], cors: true, maxInstances: 3 }, async (req, res) => {
  try {
    const { startCity, districtId, days, budget, travellers, month, preference } = req.body || {};
    if (!districtId || !(days >= 1 && days <= 7) || !(budget >= 1000)) return res.status(400).json({ error: "Check days (1-7) and budget (at least 1000)." });

    const db = admin.firestore();
    const get = async (c) => (await db.collection(c).where("districtId", "==", districtId).get()).docs.map((d) => d.data());
    const [places, stays] = await Promise.all([get("places"), get("stays")]);
    if (!places.length) return res.status(404).json({ error: "No places stored for this district yet." });

    // Straight-line distances between places, so the model plans short hops
    const distances = places.flatMap((a, i) => places.slice(i + 1).map((b) => ({ from: a.name, to: b.name, km: km(a, b) })));
    const data = {
      places: places.map(({ name, category, bestMonths, bestTime, entryFee }) => ({ name, category, bestMonths, bestTime, entryFee })),
      stays: stays.map(({ name, type, priceMin, priceMax }) => ({ name, type, priceMin, priceMax })),
      distances,
    };

    const prompt = `You are a Karnataka trip planner. Plan ${days} day(s) for ${travellers} traveller(s) from ${startCity} in ${month}, total budget Rs ${budget}, preference: ${preference}.
Use ONLY the places and stays in the DATA. Never invent a place, hotel or price. Use "TODO" entry fees as 0 and say so in budgetNote.
If the budget is too low, say so in budgetNote and give the closest realistic plan.
Reply with JSON only, no other text, in exactly this shape:
{"summary":string,"budgetNote":string,"bestMonthNote":string,"days":[{"day":number,"places":[{"name":string,"bestTime":string}],"stopsOnTheWay":[string],"stay":{"name":string,"pricePerNight":number}},...],"costBreakdown":{"stay":number,"food":number,"transport":number,"entryFees":number}}
stopsOnTheWay may only contain places from the DATA, otherwise leave it empty.
DATA: ${JSON.stringify(data)}`;

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": process.env.LLM_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: "claude-sonnet-5-5", max_tokens: 1500, messages: [{ role: "user", content: prompt }] }),
    });
    const out = await r.json();
    const text = (out.content?.[0]?.text || "").replace(/```json|```/g, "").trim();
    res.json(JSON.parse(text));
  } catch (err) {
    res.status(502).json({ error: "The planner could not build a plan. Try again. (" + err.message + ")" });
  }
});
